import requests
import time
import pandas as pd

# ── CONFIG: map a short slug to its OpenAlex institution ID ────────────────
INSTITUTIONS = {
    "mit":      "I63966007",   # Massachusetts Institute of Technology
    "ou":       "I8692664",    # University of Oklahoma
    "osu":      "I115475287",   # Oklahoma State University
    "dartmouth":"I107672454",  # Dartmouth College
    "cornell":  "I205783295",  # Cornell University
    "harvard":  "I136199984",  # Harvard University
}

PER_PAGE  = 100
MAX_PAGES = 500
YEAR_MIN, YEAR_MAX = 1955, 2025
DELAY = 1.5    # polite pause between pages

for slug, inst_id_num in INSTITUTIONS.items():
    inst_url = f"https://openalex.org/{inst_id_num}"
    authors = {}

    print(f"\n=== Collecting for {slug.upper()} ({inst_url}) ===")

    for page in range(1, MAX_PAGES+1):
        print(f"[{slug}] Fetching page {page}…")
        url = (
            "https://api.openalex.org/works"
            f"?filter=institutions.id:{inst_id_num},publication_year:{YEAR_MIN}-{YEAR_MAX}"
            f"&per_page={PER_PAGE}&page={page}"
        )
        resp = requests.get(url)
        if resp.status_code != 200:
            print(f"[{slug}] Error on page {page}: {resp.status_code}")
            break

        data = resp.json().get("results", [])
        if not data:
            print(f"[{slug}] No more results.")
            break

        for work in data:
            year = work.get("publication_year")
            if not isinstance(year, int) or not (YEAR_MIN <= year <= YEAR_MAX):
                continue

            for auth in work.get("authorships", []):
                a = auth.get("author", {})
                aid = a.get("id"); name = a.get("display_name", "Unknown")
                if not aid:
                    continue

                # check if this work lists our target inst
                for inst in auth.get("institutions", []):
                    iid = inst.get("id")
                    iname = inst.get("display_name", "Unknown")
                    if iid and iid.lower() == inst_url.lower():
                        rec = authors.setdefault(aid, {
                            "name": name,
                            "inst_1_id": iid,
                            "inst_1_name": iname,
                            "year_start_1": year,
                            "year_end_1": year
                        })
                        rec["year_start_1"] = min(rec["year_start_1"], year)
                        rec["year_end_1"]   = max(rec["year_end_1"],   year)
                        break

        time.sleep(DELAY)

    # dump to CSV
    df = pd.DataFrame.from_dict(authors, orient="index")
    df.reset_index(inplace=True)
    df.rename(columns={"index":"author_id"}, inplace=True)
    out_fn = f"{slug}_only_affiliations.csv"
    df.to_csv(out_fn, index=False)
    print(f"[{slug}] Saved {len(df)} authors → {out_fn}")
